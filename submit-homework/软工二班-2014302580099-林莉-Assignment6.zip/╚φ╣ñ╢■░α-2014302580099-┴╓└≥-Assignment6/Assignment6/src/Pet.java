
/**
 * Created by LinLi on 2015/12/2.
 */
public class Pet {
    private int id;
    private String name;
    private String eat;
    private String drink;
    private String live;
    private String hobby;

    public void setId(int id)
    {
        this.id=id;
    }
    public int getId(){
        return id;
    }

    public void setName(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return name;
    }

    public void setEat(String eat)
    {
        this.eat=eat;
    }
    public String getEat()
    {
        return eat;
    }

    public void setDrink(String drink)
    {
        this.drink=drink;
    }
    public String getDrink()
    {
        return drink;
    }

    public void setLive(String live)
    {
        this.live=live;
    }
    public String getLive()
    {
        return live;
    }

    public void setHobby(String hobby)
    {
        this.hobby=hobby;
    }
    public String getHobby()
    {
        return hobby;
    }

}
