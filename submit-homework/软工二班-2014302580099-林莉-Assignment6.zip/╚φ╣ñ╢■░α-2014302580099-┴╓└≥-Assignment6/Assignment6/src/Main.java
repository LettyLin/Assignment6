
/**
 * Created by LinLi on 2015/12/2.
 */
public class Main {
    public static void main(String[] args)
    {
       LogGUI LogGUI =new LogGUI();
    }
}
