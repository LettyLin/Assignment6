import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by LinLi on 2015/12/2.
 */
public class LogGUI extends JFrame {
    private Pet pet;

    private JFrame jf;
    private JTextField name;
    private JTextField password;
    private String nameTxt;
    private String passwordTxt;

    private int page=0;
    private int cartPage=0;

    private Container c;

    public LogGUI() {
        jf = new JFrame();
        c = jf.getContentPane();
        createLogPage();
        jf.setSize(400, 500);
        jf.setVisible(true);
        jf.setResizable(false);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public void createLogPage() {
        c.removeAll();
        JPanel jPanelMain = new JPanel();
        JPanel jPanelTxtArea = new JPanel();
        JLabel jLabel = new JLabel("welcome to pets market");

        name = new JTextField();
        password = new JTextField();
        JButton log = new JButton("login");
        JButton register = new JButton("register");
        jLabel.setBounds(130, 50, 180, 60);

        name.setBounds(100, 100, 200, 40);
        password.setBounds(100, 160, 200, 40);

        log.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (identify()) {
                    createMainPage(++page);
                    jf.setVisible(true);
                }
            }
        });

        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nameTxt = name.getText();
                passwordTxt = password.getText();
                if(!nameTxt.isEmpty()&&!passwordTxt.isEmpty()) {
                    connectMYSQL.getInstance().Execute("insert into 2014302580099_users(name,password) values ('" + nameTxt + "','" + passwordTxt + "');");
                    jf.setVisible(true);
                }
            }
        });
        jPanelMain.setLayout(null);
        jPanelTxtArea.setLayout(new GridLayout(1, 2));
        jPanelTxtArea.setBounds(100, 220, 200, 40);
        jPanelTxtArea.add(log);
        jPanelTxtArea.add(register);

        jPanelMain.add(jLabel);
        jPanelMain.add(name);
        jPanelMain.add(password);
        jPanelMain.add(jPanelTxtArea);

        c.add(jPanelMain);
    }

    public void createMainPage(int i) {
        c.removeAll();
        JPanel jPanelBig = new JPanel();
        jPanelBig.setLayout(new BorderLayout(10, 10));
        JPanel jPanelSouth = new JPanel();//按钮
        JPanel jPanelMain = new JPanel();
        jPanelMain.setLayout(new GridLayout(2,2));

        ArrayList<Pet> pets = new ArrayList<>();
        ResultSet rs = connectMYSQL.getInstance().Search("select * from 2014302580099_pet");
        int tmp=0;
        try {
            while (rs.next()) {
                if (tmp >= 4*(i-1) && tmp < 4*i) {
                    pet = new Pet();
                    pet.setId(Integer.parseInt(rs.getString(1)));
                    pet.setName(rs.getString(2));
                    pet.setEat(rs.getString(3));
                    pet.setDrink(rs.getString(4));
                    pet.setLive(rs.getString(5));
                    pet.setHobby(rs.getString(6));
                    pets.add(pet);
                    ++tmp;
                }else{
                    ++tmp;
                    continue;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        int money=100;
        for(Pet one:pets) {
            money+=20;
            JLabel[] jLabels = new JLabel[6];

            JPanel jPanelQuarter = new JPanel();
            jPanelQuarter.setLayout(new GridLayout(1, 2));
            JPanel jPanelName = new JPanel();
            jPanelName.setLayout(new FlowLayout(1, 20, 10));
            JPanel jPanelInfo = new JPanel();
            jPanelInfo.setLayout(new FlowLayout(0, 10, 10));
            JLabel price = new JLabel(money+" ");
            JButton add = new JButton("add");
            add.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    connectMYSQL.getInstance().Execute("INSERT INTO 2014302580099_cartpets (user,id,name,eat,drink,live,hobby) values ('"+
                    nameTxt+"',"+one.getId()+",'"+one.getName()+"','"+one.getEat()+"','"+one.getDrink()+
                    "','"+one.getLive()+"','"+one.getHobby()+"');");
                }
            });

            jLabels[0] = new JLabel("name:" + one.getName(), JLabel.CENTER);
            jLabels[1] = new JLabel("eat:" + one.getEat());
            jLabels[2] = new JLabel("drink:" + one.getDrink());
            jLabels[3] = new JLabel("live:" + one.getLive());
            jLabels[4] = new JLabel("hobby:" + one.getHobby());


            jPanelName.add(jLabels[0]);
            jPanelName.add(price);
            jPanelName.add(add);
            jPanelInfo.add(jLabels[1]);
            jPanelInfo.add(jLabels[2]);
            jPanelInfo.add(jLabels[3]);
            jPanelInfo.add(jLabels[4]);
            jPanelQuarter.add(jPanelName);
            jPanelQuarter.add(jPanelInfo);
            jPanelMain.add(jPanelQuarter);
        }


        JButton back = new JButton("back");
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createLogPage();
                jf.setVisible(true);
            }
        });
        JButton cart = new JButton("cart");
        cart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ResultSet resultSet = connectMYSQL.getInstance().Search("SELECT * FROM 2014302580099_cartpets;");
                    resultSet.last();
                    int rows = resultSet.getRow();
                    int pages = (rows % 4 == 0 ? rows / 4 : rows / 4 + 1);
                    cartPage=0;
                    //if (cartPage+1 <=pages){
                        createCartPage(++cartPage);
                        jf.setVisible(true);
                    //}
                }catch (SQLException s)
                {
                    s.printStackTrace();
                }
            }
        });
        JButton next =new JButton("next");
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ResultSet resultSet = connectMYSQL.getInstance().Search("SELECT * FROM 2014302580099_pet;");
                    resultSet.last();
                    int rows = resultSet.getRow();
                    int pages = (rows % 4 == 0 ? rows / 4 : rows / 4 + 1);
                    if (page+1 <=pages){
                        createMainPage(++page);
                        jf.setVisible(true);
                    }
                }catch (SQLException s)
                {
                    s.printStackTrace();
                }
            }
        });
        JButton last=new JButton("last");
        last.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (page-1 > 0) {
                    createMainPage(--page);
                    jf.setVisible(true);
                }
            }
        });

        jPanelSouth.add(last);
        jPanelSouth.add(next);
        jPanelSouth.add(cart);
        jPanelSouth.add(back);

        jPanelBig.add(jPanelMain, BorderLayout.CENTER);
        jPanelBig.add(jPanelSouth, BorderLayout.SOUTH);
        c.add(jPanelBig);
    }

    public void createCartPage(int i) {
        c.removeAll();
        JPanel jPanelBig = new JPanel();
        jPanelBig.setLayout(new BorderLayout(10, 10));
        JPanel jPanelNorth = new JPanel();//按钮
        JPanel jPanelSouth = new JPanel();//按钮
        JPanel jPanelMain = new JPanel();
        jPanelMain.setLayout(new GridLayout(2,2));

        ArrayList<Pet> pets = new ArrayList<>();
        ResultSet rs = connectMYSQL.getInstance().Search("select * from 2014302580099_cartpets where user='"+nameTxt+"';");
        int tmp=0;
        try {
            while (rs.next()) {
                if (tmp >= 4*(i-1) && tmp < 4*i) {
                    pet = new Pet();
                    pet.setId(Integer.parseInt(rs.getString(2)));
                    pet.setName(rs.getString(3));
                    pet.setEat(rs.getString(4));
                    pet.setDrink(rs.getString(5));
                    pet.setLive(rs.getString(6));
                    pet.setHobby(rs.getString(7));
                    pets.add(pet);
                    ++tmp;
                }else{
                    ++tmp;
                    continue;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for(Pet one:pets) {
            JLabel[] jLabels = new JLabel[6];

            JPanel jPanelQuarter = new JPanel();
            jPanelQuarter.setLayout(new GridLayout(1, 2));
            JPanel jPanelName = new JPanel();
            jPanelName.setLayout(new FlowLayout(1, 20, 10));
            JPanel jPanelInfo = new JPanel();
            jPanelInfo.setLayout(new FlowLayout(0, 10, 10));
            JButton buy = new JButton("buy");
            buy.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    connectMYSQL.getInstance().Execute("delete from 2014302580099_pet where id=" + one.getId() + ";");
                    connectMYSQL.getInstance().Execute("delete from 2014302580099_cartpets where id=" + one.getId() + ";");
                }
            });

            jLabels[0] = new JLabel("name:" + one.getName(), JLabel.CENTER);
            jLabels[1] = new JLabel("eat:" + one.getEat());
            jLabels[2] = new JLabel("drink:" + one.getDrink());
            jLabels[3] = new JLabel("live:" + one.getLive());
            jLabels[4] = new JLabel("hobby:" + one.getHobby());


            jPanelName.add(jLabels[0]);
            jPanelName.add(buy);
            jPanelInfo.add(jLabels[1]);
            jPanelInfo.add(jLabels[2]);
            jPanelInfo.add(jLabels[3]);
            jPanelInfo.add(jLabels[4]);
            jPanelQuarter.add(jPanelName);
            jPanelQuarter.add(jPanelInfo);
            jPanelMain.add(jPanelQuarter);
        }


        JButton back = new JButton("back");
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                page=0;
                createMainPage(++page);
                jf.setVisible(true);
            }
        });

        JButton next =new JButton("next");
        next.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ResultSet resultSet = connectMYSQL.getInstance().Search("SELECT * FROM 2014302580099_cartpets where user='"+nameTxt+"';");
                    resultSet.last();
                    int rows = resultSet.getRow();
                    int pages = (rows % 4 == 0 ? rows / 4 : rows / 4 + 1);
                    if (cartPage+1 <=pages){
                        createCartPage(++cartPage);
                        jf.setVisible(true);
                    }
                }catch (SQLException s)
                {
                    s.printStackTrace();
                }
            }
        });
        JButton last=new JButton("last");
        last.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (cartPage-1 > 0) {
                    createCartPage(--cartPage);
                    jf.setVisible(true);
                }
            }
        });

        jPanelSouth.add(last);
        jPanelSouth.add(next);
        jPanelSouth.add(back);

        jPanelBig.add(jPanelMain, BorderLayout.CENTER);
        jPanelBig.add(jPanelNorth, BorderLayout.NORTH);
        jPanelBig.add(jPanelSouth, BorderLayout.SOUTH);
        c.add(jPanelBig);
    }

    public boolean identify() {
        nameTxt = name.getText();
        passwordTxt = password.getText();

        ResultSet rs = null;
        try {
            rs = connectMYSQL.getInstance().Search("select * from 2014302580099_users where name='" + nameTxt + "';");
            if (rs.next()) {
                if (passwordTxt.equals(rs.getString(2))) {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
