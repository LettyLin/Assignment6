import java.sql.*;

/**
 * Created by LinLi on 2015/12/2.
 */
public class connectMYSQL {
    private static connectMYSQL ourInstance = new connectMYSQL("jdbc:mysql://127.0.0.1:3306/my_schema","root","123456");

    private String url;
    private String username;
    private String password;
    private Connection con;
    private Statement statement;
    public static connectMYSQL getInstance() {
        return ourInstance;
    }

    private connectMYSQL(String _url,String _username,String _password) {
        url=_url;
        username=_username;
        password=_password;

        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con= DriverManager.getConnection(url,username,password);
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public Connection getCon()
    {
        return con;
    }
//����
    public void Execute(String sql)
    {
        try{
            statement=con.createStatement();
            statement.executeUpdate(sql);
        }catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
    //��ѯ
    public ResultSet Search(String sql)
    {
        ResultSet rs=null;
        try{
            statement=con.createStatement();
            rs=statement.executeQuery(sql);
        }catch (SQLException e)
        {
            e.printStackTrace();
        }
        return rs;
    }
}
